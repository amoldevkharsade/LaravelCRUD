<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// Route::Get('/',function($age)  
// {  
//   return view('welcome');  
// })-> middleware('age');   

use App\Http\Controllers\CompanyCRUDController;
 
Route::resource('companies', CompanyCRUDController::class);

// validation for text input route 
use App\Http\Controllers\PostController;
 
Route::get('/post/create', [PostController::class, 'create']);
Route::post('/post', [PostController::class, 'store']);

// route for middleware

// Route::get('role',[
// 'middleware' => 'CheckAge:editor',
// 'uses' => 'TestmiddlewareController@index',
// ]);
use App\Http\Controllers\TestmiddlewareController;
Route::get('role',[
'middleware' => 'Role:editor',
'uses' => 'TestmiddlewareController@index',
]);

//use App\Http\Controllers\TestmiddlewareController;

use App\Http\Controllers\HomeController;
use App\Http\Middleware\CheckStatus;

Route::middleware([CheckStatus::class])->group(function(){

Route::get('home', [HomeController::class,'home']);

});